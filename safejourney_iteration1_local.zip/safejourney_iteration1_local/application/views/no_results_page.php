<div style="padding-top:100px; padding-left: 10%; padding-right: 10%">

<p>Input Postcode: <?php echo $postcode; ?></p>
<p>Total Results: <?php echo $result_row; ?></p>
<p>Selected Period: <?php echo $period; ?></p>

<p>Sorry, No match results.</p>

</div>